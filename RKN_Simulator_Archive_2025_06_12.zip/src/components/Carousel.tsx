import { useEffect, useMemo } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { SERVICES } from '../data/services';

interface Props {
  isSpinning: boolean;
  winner: any;
}

const Carousel = ({ isSpinning, winner }: Props) => {
  const controls = useAnimation();

  // Оптимизируем количество дубликатов для производительности
  const repeatedServices = useMemo(() => [
    ...SERVICES,
    ...SERVICES,
    ...SERVICES
  ], []);

  useEffect(() => {
    if (isSpinning) {
      // Победитель уже определен, начинаем анимацию: быстрое вращение -> замедление -> остановка
      const winnerIndex = SERVICES.findIndex(s => s.id === winner.id);
      const centerOffset = Math.floor(repeatedServices.length / 2);

      // Высота одного элемента (карточка + gap)
      const itemHeight = 220; // 200px карточка + 20px gap

      // Финальная позиция
      const finalPosition = -(centerOffset + winnerIndex) * itemHeight;

      // Сначала быстрое вращение, затем замедление и остановка на нужной карточке
      controls.start({
        y: [0, -8000, finalPosition - 100, finalPosition], // Сначала старт, затем быстрое вращение, проскок, затем точная остановка
        transition: {
          duration: 5, // Общая продолжительность анимации
          ease: [0.25, 0.1, 0.3, 1], // Эластичная функция для эффекта замедления
          times: [0, 0.5, 0.85, 1] // Временные метки для анимации: быстрое вращение -> замедление -> проскок -> точная остановка
        }
      });
    } else {
      // Начальная позиция
      controls.set({ y: 0 });
    }
  }, [isSpinning, winner, controls, repeatedServices]);

  // Предварительно вычисляем стили для оптимизации
  const getServiceStyle = (index: number) => {
    const distanceFromCenter = Math.abs(index - repeatedServices.length / 2);
    const scale = Math.max(0.7, 1 - distanceFromCenter * 0.05);

    return {
      width: '280px',
      height: '200px',
      transform: `scale(${scale})`,
      boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2), inset 0 0 20px rgba(255, 255, 255, 0.5)'
    };
  };

  return (
    <div className="relative w-full h-[660px] overflow-hidden">
      {/* Индикатор центра (рамка выделения) */}
      <div className="absolute left-0 right-0 top-1/2 transform -translate-y-1/2 z-20 pointer-events-none px-4">
        <div
          className="h-[200px] border-4 border-pink-500 rounded-3xl
            bg-gradient-to-r from-pink-500/10 to-rose-500/10 backdrop-blur-sm"
          style={{
            boxShadow: '0 0 30px rgba(255, 62, 108, 0.5), inset 0 0 30px rgba(255, 255, 255, 0.1)'
          }}
        />
      </div>

      {/* Градиентные маски сверху и снизу */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-pink-500/0 to-transparent z-10 pointer-events-none" />
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-orange-400/0 to-transparent z-10 pointer-events-none" />

      {/* Барабан */}
      <motion.div
        animate={controls}
        className="flex flex-col items-center gap-5 py-[230px]"
      >
        {repeatedServices.map((service, index) => (
          <div
            key={`${service.id}-${index}`}
            className="flex items-center justify-center bg-white/95 backdrop-blur-md
              rounded-3xl shadow-2xl border-2 border-white/50"
            style={getServiceStyle(index)}
          >
            <img
              src={service.logo}
              alt={service.name}
              className="max-w-[80%] max-h-[80%] object-contain"
              loading="lazy"
            />
          </div>
        ))}
      </motion.div>
    </div>
  );
};

export default Carousel;